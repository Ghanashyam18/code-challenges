// JavaScript Document

//INIT GLOBLE VARIABLES 
var x;
var y;
var a;
var tot;
var ppl;
//FIRST FUNCTION FROM THE DOWPDOWN MENU
function myFunction(){
	//GIVE EACH OPTION A VALUE
	if (document.getElementById("zones").value === "1"){
		x=1;
	}
	if (document.getElementById("zones").value === "2"){
		x=2;
	}
	if (document.getElementById("zones").value === "3"){
		x=3;
	}
	if (document.getElementById("zones").value === "4"){
		x=4;
	}
	if (document.getElementById("zones").value === "5"){
		x=5;
	}
	//ANYTIME RIDES
	//....................................................... 
	//....................................................... 
	//SEE IF THEY SELECT A ZONE AND ANYTIME OPTION
	//USING DOCUMENT DISPLAY THE AMOUNT
	if(x===1 && y===3){
		document.getElementById("total").innerHTML="$40.00";

	}
	if(x===2 && y===3){
		document.getElementById("total").innerHTML="$47.50";

	}
	if(x===3 && y===3){
		document.getElementById("total").innerHTML="$57.50";

	}
	if(x===4 && y===3){
		document.getElementById("total").innerHTML="$65.00";

	}
	if(x===5 && y===3){
		document.getElementById("total").innerHTML="$82.50";

	}
	// ....................................................... 
	// ....................................................... 
	//  FARE FOR ZONE ONE-->

	if(x ===1 && y===1 && a===1){
		tot=5.25;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===1 && y===1 && a===2){
		tot=6;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===1 && y===2 && a===1){
		tot=4.25;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===1 && y===2 && a===2){
		tot=5;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	//  FARE FOR ZONE TWO
	// ....................................................... 
	// ....................................................... 
		
	if(x ===2 && y===1 && a===1){
		tot=5.25;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===2 && y===1 && a===2){
		tot=6;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===2 && y===2 && a===1){
		tot=4.25;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===2 && y===2 && a===2){
		tot=5;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	// ....................................................... 
	// ....................................................... 
	//  FARE FOR ZONE THREE-->
	// ....................................................... 
	// ....................................................... 
		
	if(x ===3 && y===1 && a===1){
		tot=6;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===3 && y===1 && a===2){
		tot=7;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===3 && y===2 && a===1){
		tot=5.25;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===3 && y===2 && a===2){
		tot=7;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	// ....................................................... 
	// ....................................................... 
			//  FARE FOR ZONE FOUR
	// ....................................................... 
	// ....................................................... 
		
	if(x ===4 && y===1 && a===1){
		tot=6.75;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===4 && y===1 && a===2){
		tot=8;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===4 && y===2 && a===1){
		tot=5.25;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===4 && y===2 && a===2){
		tot=7;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	// ....................................................... 
	// ....................................................... 
		//  FARE FOR ZONE FIVE
	// ....................................................... 
	// ....................................................... 
		
	if(x ===5 && y===1 && a===1){
		tot=9.25;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===5 && y===1 && a===2){
		tot=10;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===5 && y===2 && a===1){
		tot=9.25;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===5 && y===2 && a===2){
		tot=10;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	// ....................................................... 
	// ....................................................... 
	
}

function myTime(){
	if(document.getElementById("time").value === "weekDay"){
	    y=1;
		document.getElementById("msg").innerHTML="";

	}
	if(document.getElementById("time").value === "weekendEvening"){
		y=2;
		document.getElementById("msg").innerHTML="";

	}
	if(document.getElementById("time").value === "anytime"){
		y=3;
		document.getElementById("msg").innerHTML="You will have total of 10 rides";

	}
	// ANYTIME RIDES 
	// ....................................................... 
	// ....................................................... 

	if(x===1 && y===3){
		document.getElementById("total").innerHTML="$40.00";

	}
	if(x===2 && y===3){
		document.getElementById("total").innerHTML="$47.50";
	}
	if(x===3 && y===3){
		document.getElementById("total").innerHTML="$57.50";

	}
	if(x===4 && y===3){
		document.getElementById("total").innerHTML="$65.00";

	}
	if(x===5 && y===3){
		document.getElementById("total").innerHTML="$82.50";

	}

	// ....................................................... 
	// ....................................................... 
	// FARE FOR ZONE ONE

	if(x ===1 && y===1 && a===1){
		tot=5.25;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===1 && y===1 && a===2){
		tot=6;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===1 && y===2 && a===1){
		tot=4.25;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===1 && y===2 && a===2){
		tot=5;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	// ....................................................... 
	// ....................................................... 
		//  FARE FOR ZONE TWO
	// ....................................................... 
	// ....................................................... 
		
	if(x ===2 && y===1 && a===1){
		tot=5.25;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===2 && y===1 && a===2){
		tot=6;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===2 && y===2 && a===1){
		tot=4.25;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===2 && y===2 && a===2){
		tot=5;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	// ....................................................... 
	// ....................................................... 
		//  FARE FOR ZONE THREE
	// ....................................................... 
	// ....................................................... 
		
	if(x ===3 && y===1 && a===1){
		tot=6;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===3 && y===1 && a===2){
		tot=7;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===3 && y===2 && a===1){
		tot=5.25;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===3 && y===2 && a===2){
		tot=7;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	// ....................................................... 
	// ....................................................... 
		//  FARE FOR ZONE FOUR
	// ....................................................... 
	// ....................................................... 
		
	if(x ===4 && y===1 && a===1){
		tot=6.75;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===4 && y===1 && a===2){
		tot=8;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===4 && y===2 && a===1){
		tot=5.25;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===4 && y===2 && a===2){
		tot=7;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	// ....................................................... 
	// ....................................................... 
		//  FARE FOR ZONE FIVE
	// ....................................................... 
	// ....................................................... 
		
	if(x ===5 && y===1 && a===1){
		tot=9.25;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===5 && y===1 && a===2){
		tot=10;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===5 && y===2 && a===1){
		tot=9.25;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===5 && y===2 && a===2){
		tot=10;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	// ....................................................... 
	// ....................................................... 

}
function myChoice(){
	var stat = document.getElementById("sta").checked;
	var onbo = document.getElementById("onb").checked;
	
	if(stat === true){
		a =1;
	}
	if(onbo=== true){
		a = 2;
	}
 	
	// WEEKDAYS FARE FOR ZONE ONE
	// ....................................................... 
	// ....................................................... 

	if(x ===1 && y===1 && a===1){
		tot=5.25;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===1 && y===1 && a===2){
		tot=6;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===1 && y===2 && a===1){
		tot=4.25;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===1 && y===2 && a===2){
		tot=5;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	// ....................................................... 
	// ....................................................... 
		//  FARE FOR ZONE TWO
	// ....................................................... 
	// ....................................................... 
		
	if(x ===2 && y===1 && a===1){
		tot=5.25;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===2 && y===1 && a===2){
		tot=6;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===2 && y===2 && a===1){
		tot=4.25;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===2 && y===2 && a===2){
		tot=5;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	// ....................................................... 
	// ....................................................... 
		//  FARE FOR ZONE THREE
	// ....................................................... 
	// ....................................................... 
		
	if(x ===3 && y===1 && a===1){
		tot=6;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===3 && y===1 && a===2){
		tot=7;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===3 && y===2 && a===1){
		tot=5.25;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===3 && y===2 && a===2){
		tot=7;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	// ....................................................... 
	// ....................................................... 
		//  FARE FOR ZONE FOUR
	// ....................................................... 
	// ....................................................... 
		
	if(x ===4 && y===1 && a===1){
		tot=6.75;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===4 && y===1 && a===2){
		tot=8;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===4 && y===2 && a===1){
		tot=5.25;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===4 && y===2 && a===2){
		tot=7;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	// ....................................................... 
	// ....................................................... 
		//  FARE FOR ZONE FIVE
	// ....................................................... 
	// ....................................................... 
		
	if(x ===5 && y===1 && a===1){
		tot=9.25;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===5 && y===1 && a===2){
		tot=10;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===5 && y===2 && a===1){
		tot=9.25;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===5 && y===2 && a===2){
		tot=10;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	// ....................................................... 
	// ....................................................... 

}

function myPeople(){
	ppl = document.getElementById("up").value;
	
	// FARE FOR ZONE ONE
	// ....................................................... 
	// ....................................................... 
		
	if(x ===1 && y===1 && a===1){
		tot=5.25;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===1 && y===1 && a===2){
		tot=6;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===1 && y===2 && a===1){
		tot=4.25;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===1 && y===2 && a===2){
		tot=5;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	// ....................................................... 
	// ....................................................... 
		
	//  FARE FOR ZONE TWO
	// ....................................................... 
	// ....................................................... 
		
	if(x ===2 && y===1 && a===1){
		tot=5.25;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===2 && y===1 && a===2){
		tot=6;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===2 && y===2 && a===1){
		tot=4.25;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===2 && y===2 && a===2){
		tot=5;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	// ....................................................... 
	// ....................................................... 
		//  FARE FOR ZONE THREE
	// ....................................................... 
	// ....................................................... 
		
	if(x ===3 && y===1 && a===1){
		tot=6;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===3 && y===1 && a===2){
		tot=7;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===3 && y===2 && a===1){
		tot=5.25;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===3 && y===2 && a===2){
		tot=7;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	// ....................................................... 
	// ....................................................... 
		//  FARE FOR ZONE FOUR
	// ....................................................... 
	// ....................................................... 
		
	if(x ===4 && y===1 && a===1){
		tot=6.75;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===4 && y===1 && a===2){
		tot=8;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===4 && y===2 && a===1){
		tot=5.25;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===4 && y===2 && a===2){
		tot=7;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	// ....................................................... 
	// ....................................................... 
		//  FARE FOR ZONE FIVE
	// ....................................................... 
	// ....................................................... 
		
	if(x ===5 && y===1 && a===1){
		tot=9.25;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===5 && y===1 && a===2){
		tot=10;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===5 && y===2 && a===1){
		tot=9.25;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	if(x ===5 && y===2 && a===2){
		tot=10;
		tot=tot*ppl;
		document.getElementById("total").innerHTML = "$"+tot;
	}
	// ....................................................... 
	// ....................................................... 
	
}
